var mongoose = require('mongoose');

var voteSchema = {
  datetime: { type: Date, default: Date.now },
  ssesid: { type: String},
  usrip: { type: String},
  image0: { type: String},
  image1: { type: String},
  useremail: { type: String},
  vote: { type: Number}
}

module.exports = new mongoose.Schema(voteSchema);
module.exports.categorySchema = voteSchema;
