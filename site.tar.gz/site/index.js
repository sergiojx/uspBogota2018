var express = require('express');
var session = require('express-session');
var wagner = require('wagner-core');
var bodyparser = require('body-parser');

require('./models')(wagner);

var app = express();

app.use(session({
  name: 'astrolopitekus_moduminiouous',
  secret: 'ATHERYSGYyg356',
  saveUninitialized: true,
  resave: true
}));

app.use('/', require('./api')(wagner));
app.use(bodyparser.json());
app.enable('trust proxy');
app.use(express.static('static'));


/*
app.use(function printSession(req, res, next) {
  console.log('req.session', req.session);
  return next();
});
*/
app.listen(80);
console.log('Listening on port 80!');
