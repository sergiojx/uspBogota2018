var mongoose = require('mongoose');

var imageSchema = {
  name: { type: String},
  lat: { type: Number},
  logt: { type: Number},
  path: { type: String},
  loc: { type: Number},
  vcnt: { type: Number}
}

module.exports = new mongoose.Schema(imageSchema);
module.exports.categorySchema = imageSchema;
