var bodyparser = require('body-parser');
var express = require('express');
var status = require('http-status');
var mongoose = require('mongoose');
var randomstring = require("randomstring");
var fs = require('fs');

module.exports = function(wagner) {
  var api = express.Router();

  api.use(bodyparser.json());

  api.get('/imgset', wagner.invoke(function(Image) {
    return function(req, res) {


       var chapineroVerification = [
         {"image0":"4.62923564526_-74.065800863_-90.jpg", "image1":"4.68576019288_-74.0546666646_135.jpg"},
         {"image0":"4.63824830469_-74.0657458206_0.jpg", "image1":"4.65308841675_-74.0551230241_180.jpg"},
         {"image0":"4.64104575515_-74.0660675719_90.jpg", "image1":"4.64933680657_-74.0530012279_-45.jpg"},
         {"image0":"4.64139980728_-74.0655107421_45.jpg", "image1":"4.66906504559_-74.0399077677_135.jpg"},
         {"image0":"4.64325149801_-74.0656709126_135.jpg", "image1":"4.67061110698_-74.0398962637_180.jpg"},
         {"image0":"4.6307584954_-74.0661885857_45.jpg", "image1":"4.6519059_-74.0536661_-135.jpg"},
         {"image0":"4.63132993388_-74.06619847_0.jpg", "image1":"4.65924216364_-74.0536616347_180.jpg"},
         {"image0":"4.6794205_-74.0584418_180.jpg", "image1":"4.6528265304_-74.0539190259_180.jpg"},
         {"image0":"4.62877402551_-74.0679745003_45.jpg", "image1":"4.6391094_-74.0587153_-90.jpg"},
         {"image0":"4.6461951_-74.0536636_180.jpg", "image1":"4.65181027821_-74.053908828_-45.jpg"}
       ]


        var verify = 0

        if(req.session.u)
        {
          // logic for perception vote verification
          var currentDate = +new Date()
          var lastVoteLapse = currentDate - req.session.lstRq
          if((lastVoteLapse > 47673) || (req.session.votes%72 == 0))
          {
              req.session.lstRq = +new Date();
              //desable checking image pair
              //verify = 1;
              verify = 0;
          }
        }
        else
        {
          req.session.u = randomstring.generate();
          req.session.votes = 0;
          req.session.lstRq = +new Date();
        }
        if(verify == 0)
        {
          // TODO: What happen if there just 3,2, or 1 voutless image???
          Image.find().sort({"vcnt":1}).limit(1).exec(function(err,img){
            if(err)
            {
              return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });
            }
            var lessVoteCount = img[0].vcnt;
            console.log("lessVoteCount: " + lessVoteCount);
            Image.count({"vcnt":lessVoteCount}).exec(function(err, count){
              var random0 = Math.floor(Math.random() * count);
              var random1 = Math.floor(Math.random() * count);
              console.log("less vouted amount: " + count);
              if(random0 == random1)
              {
                random1 = Math.floor(Math.random() * count);
                if(random0 == random1)
                {
                  random1 = Math.floor(Math.random() * count);
                  if(random0 == random1)
                  {
                    random1 = Math.floor(Math.random() * count);
                  }
                }
              }
              console.log("random0: " + random0);
              console.log("random1: " + random1);
                //retrive image 0
              Image.findOne({"vcnt":lessVoteCount}).skip(random0).exec(
                function (err, image0) {
                  if (err)
                  {
                    return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });
                  }
                  var base64Img0 = base64_encode(__dirname + '/static/imagebank' + image0.path);
                  var imgName0 = image0.name;
                  //retrive image 1
                  Image.findOne({"vcnt":lessVoteCount}).skip(random1).exec(
                    function (err, image1) {
                      if (err)
                      {
                        return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });
                      }
                      var base64Img1 = base64_encode(__dirname + '/static/imagebank' + image1.path);
                      var imgName1 = image1.name;
                      return res.json({ img0: base64Img0, name0:imgName0, img1:base64Img1, name1:imgName1 });

                    });
                });
            });

          });          
        }
        else
        {

            var verPair = Math.floor(Math.random() * 10);
            console.log("Verification State !O.O! image0: " + chapineroVerification[verPair].image0 + "image1: " + chapineroVerification[verPair].image1);
            var base64Img0 = base64_encode(__dirname + '/static/imagebank/chapinero/' + chapineroVerification[verPair].image0);
            var imgName0 = chapineroVerification[verPair].image0;
            var base64Img1 = base64_encode(__dirname + '/static/imagebank/chapinero/' + chapineroVerification[verPair].image1);
            var imgName1 = chapineroVerification[verPair].image1;
            return res.json({ img0: base64Img0, name0:imgName0, img1:base64Img1, name1:imgName1 });
        }
    }
  }));


  api.post('/vote', wagner.invoke(function(Image, Vote) {
    return function(req, res) {
      if(req.session.u)
      {
        req.session.votes = req.session.votes + 1;
        voteObj = new Object()
        voteObj.ssesid = req.session.u;
        voteObj.usrip = req.ip;
        voteObj.image0 = req.body.img0;
        voteObj.image1 = req.body.img1;
        voteObj.useremail = 'none@none.com';
        voteObj.vote = req.body.vote;
        entry = new Vote(voteObj);
        entry.save(function (err, entry){
          if (err)
          {
            return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });
          }
          Image.findOne({ "name": req.body.img0 }).exec(
            function (err, image0)
            {
              if(err){return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });} 
              console.log(image0.vcnt)
              image0.vcnt = image0.vcnt + 1;
              console.log(image0.vcnt)
              Image.findByIdAndUpdate(image0._id, { vcnt: image0.vcnt }, { new: false }, function (err, upimage0){})
              console.log(image0 + " " + "updated");
              Image.findOne({ "name": req.body.img1 }).exec(
                function (err, image1)
                {
                  if(err){return res.status(status.INTERNAL_SERVER_ERROR).json({ error: err.toString() });}
                  console.log(image1.vcnt)
                  image1.vcnt = image1.vcnt + 1;
                  console.log(image1.vcnt)
                  Image.findByIdAndUpdate(image1._id, { vcnt: image1.vcnt }, { new: false }, function (err, upimage1){})
                  console.log(image1 + " " + "updated");
                  res.send('OK');
                }
              );
            }
          );
        });
      }
      else
      {
          res.send('OK');
      }
    }
  }));

  api.get('/', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/main.html')
  });
 
  api.get('/chapinero_actualvote_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero_actualvote_imgscore.html')
  });
	
  api.get('/chapinero_24768syntheticvote_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero_24768syntheticvote_imgscore.html')
  });
  
  api.get('/chapinero_13760syntheticvote_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero_13760syntheticvote_imgscore.html')
  });

  api.get('/usaquen_42652syntheticvote_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/usaquen_42652syntheticvote_imgscore.html')
  });

  api.get('/martires_17046syntheticvote_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/martires_17046syntheticvote_imgscore.html')
  });
  // Update June 05 2018
  api.get('/chapinero_17703actualvote_jun04_2018_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero_17703actualvote_jun04_2018_imgscore.html')
  });

  api.get('/chapinero_55040NNsyntheticvote_jun04_2018_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero_55040NNsyntheticvote_jun04_2018_imgscore.html')
  });

  api.get('/martires_37880NNsyntheticvote_jun04_2018_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/martires_37880NNsyntheticvote_jun04_2018_imgscore.html')
  });

  api.get('/usaquen_94780NNsyntheticvote_jun04_2018_imgscore', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/usaquen_94780NNsyntheticvote_jun04_2018_imgscore.html')
  });

  // Aug 11 2018
  api.get('/chapinero18959actualvoteSigma3p25u4p5mu20u30TrueSkill', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero18959actualvoteSigma3p25u4p5mu20u30TrueSkill.html')
  });

  api.get('/chapinero18959actualvoteSigma3u4mu15u35TrueSkill', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero18959actualvoteSigma3u4mu15u35TrueSkill.html')
  });

  api.get('/chapinero18959actualvoteSigma3u4mu20u30TrueSkill', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero18959actualvoteSigma3u4mu20u30TrueSkill.html')
  });

  // Aug 12 2018
  api.get('/chapinero18959actualvoteSigma3p5u5mu15u35TrueSkill', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero18959actualvoteSigma3p5u5mu15u35TrueSkill.html')
  });

  api.get('/chapinero18959actualvoteSigma3p5u5mu20u30TrueSkill', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapinero18959actualvoteSigma3p5u5mu20u30TrueSkill.html')
  });

  // Sep 7 2018
  api.get('/martiresImgSyntheticVCountSIII', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/martiresImgSyntheticVCountSIII.html')
  });

  api.get('/chapImgSyntheticVCountSIII', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/chapImgSyntheticVCountSIII.html')
  });

  api.get('/usaquenImgSyntheticVCountSIII', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/usaquenImgSyntheticVCountSIII.html')
  });

  // Sep 29 2018
  api.get('/Sh3ChapOneMatchRatingDual', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3ChapOneMatchRatingDual.html')
  });

  api.get('/Sh3MartOneMatchRatingDual', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3MartOneMatchRatingDual.html')
  });

  api.get('/Sh3UsaqOneMatchRatingDual', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3UsaqOneMatchRatingDual.html')
  });

  // Sep 30 2018
  api.get('/Sh3ChapOneMatchRatingVGG19', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3ChapOneMatchRatingVGG19.html')
  });

  api.get('/Sh3MartOneMatchRatingVGG19', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3MartOneMatchRatingVGG19.html')
  });

  api.get('/Sh3UsaqOneMatchRatingVGG19', function(req, res)
  {

    res.sendFile('/root/webperception/site/static/Sh3UsaqOneMatchRatingVGG19.html')
  });


  return api;
};

function handleOne(property, res, error, result) {
  if (error) {
    return res.
      status(status.INTERNAL_SERVER_ERROR).
      json({ error: error.toString() });
  }
  if (!result) {
    return res.
      status(status.NOT_FOUND).
      json({ error: 'Not found' });
  }

  var json = {};
  json[property] = result;
  res.json(json);
}

// function to encode file data to base64 encoded string
function base64_encode(file) {
    // read binary data
    var bitmap = fs.readFileSync(file);
    // convert binary data to base64 encoded string
    return new Buffer(bitmap).toString('base64');
}

// function to create file from base64 encoded string
function base64_decode(base64str, file) {
    // create buffer object from base64 encoded string, it is important to tell the constructor that the string is base64 encoded
    var bitmap = new Buffer(base64str, 'base64');
    // write buffer to file
    fs.writeFileSync(file, bitmap);
    console.log('******** File created from base64 encoded string ********');
}
